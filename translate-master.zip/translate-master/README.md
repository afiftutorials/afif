Translator Termux 

pkg update
pkg upgrade
pkg install git
pkg install python2

masukan kode perintah di bawah ini untuk download script tranlator
 gi clone https://github.com/kumpulanremaja/translate
kode perintah untuk menjalankan script Google terjemahan Di termus di bawah ini
 cd translate
  python2  trans.py [option]-[source] "[text]"
contoh penggunaan  : python2  trans.py ID-US "Halo admin kumpulanremaja , Apa kabar"
untuk selengkapnya cek di https://www.kumpulanremaja.com/2019/09/Translator-google-di-termux.html
